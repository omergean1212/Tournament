/**
 * @author Grigory Shaulov
 * 
 **/
package command;


public interface Command {
	double getBalance();
	void setBalance(double value);
}
